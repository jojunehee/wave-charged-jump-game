package com.jojunehee.wcjg;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class WcjgApplication {
  public static void main(String[] args){ SpringApplication.run(WcjgApplication.class, args); }
}
